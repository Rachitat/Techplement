// Booking Form Submission Handler
document.getElementById('bookingForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let course = document.getElementById('course').value;
    let date = document.getElementById('date').value;

    // Simple validation (basic)
    if (!name || !email || !course || !date) {
        alert("Please fill in all fields.");
        return;
    }

    alert(`Booking Confirmed! \nCourse: ${course} \nName: ${name} \nEmail: ${email} \nDate: ${date}`);
});

